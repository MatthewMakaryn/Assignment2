﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace RAP
{
    public class ERDAdapter
    {
        private static bool reportingErrors = false;

        private const string db = "kit206";
        private const string user = "kit206";
        private const string pass = "kit206";
        private const string server = "alacritas.cis.utas.edu.au";

        private static MySqlConnection conn = null;

        /// Creates and returns (but does not open) the connection to the database.
        private static MySqlConnection GetConnection()
        {
            if (conn == null)
            {
                //Note: This approach is not thread-safe
                string connectionString = String.Format("Database={0};Data Source={1};User Id={2};Password={3}", db, server, user, pass);
                conn = new MySqlConnection(connectionString);
            }
            return conn;
        }

        //retrieve list of basic researcher information from database
        public static List<Researcher> FetchBasicResearcherDetails() 
        {
            List<Researcher> researchers = new List<Researcher>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select id, type, given_name, family_name, title, level from researcher", conn);
                rdr = cmd.ExecuteReader();
           
                while (rdr.Read()) 
                {
                    if (rdr.GetString(1) == "Student")
                    {
                        researchers.Add(new Student
                        {
                            ID = rdr.GetInt32(0),
                            GivenName = rdr.GetString(2),
                            FamilyName = rdr.GetString(3),
                            Title = rdr.GetString(4),
                            CurrentJobLevel = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString(5))
                        }) ;
                    } 
                    else
                    {
                        researchers.Add(new Staff
                        {
                            ID = rdr.GetInt32(0),
                            GivenName = rdr.GetString(2),
                            FamilyName = rdr.GetString(3),
                            Title = rdr.GetString(4),
                            CurrentJobLevel = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString(5))
                        });
                    }
                }
            }
            catch
            {

            }
            return researchers;
        }

        //retrieve all of a specific researcher's details from the database
        public static void CompleteResearcherDetails(Researcher r)
        {
            //List<Publication> publications = new List<Publication>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select unit, campus, email, photo, degree, supervisor_id, level from researcher where id=?id", conn);
                cmd.Parameters.AddWithValue("id", r.ID);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    r.School = rdr.GetString(0);
                    r.Campus = rdr.GetString(1);
                    r.Email = rdr.GetString(2);
                    r.Photo = rdr.GetString(3);

                    //if they are a student, add student only data
                    if (r is Student)
                    {
                        (r as Student).Degree = rdr.GetString(4);
                        (r as Student).SupervisorID = rdr.GetInt32(5);
                    }
                    else 
                    //if they are staff, add list of positions
                    {
                        //retrieve all of their past positions from the database
                        List<Position> positions = new List<Position>();
                        MySqlCommand cmd3 = new MySqlCommand("select level, start, end from position where id=?id order by end desc", conn);
                        cmd3.Parameters.AddWithValue("id", r.ID);
                        rdr = cmd3.ExecuteReader();

                        while (rdr.Read())
                        {
                            positions.Add(new Position
                            {
                                Level = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString(0)),
                                Start = rdr.GetDateTime(1),
                                End = rdr.GetDateTime(2)
                            });
                        }
                        (r as Staff).Positions = positions;

                        
                    }

                }

            } 
            catch
            {

            }

            //return researcher;
        }

        public static List<Publication> FetchBasicPublicationDetails(Researcher r)
        {
            List<Publication> publications = new List<Publication>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select publication.doi, publication.year, publication.title from publication where ..........", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    publications.Add(new Publication
                    {
                        DOI = rdr.GetString(0),
                        Year = rdr.GetDateTime(1),
                        Title = rdr.GetString(2)
                    }) ;
                }
            }
            catch
            {

            }
            
            return publications;
        }

        public static void CompletePublicationDetails(Publication p)
        {
            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("authors, type, cite_as, available from publication where doi = ?doi", conn);
                cmd.Parameters.AddWithValue("doi", p.DOI);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    p.Authors = rdr.GetString(0);
                    p.Type = EnumToString.ParseEnum<OutputType>(rdr.GetString(1));
                    p.CiteAs = rdr.GetString(2);
                    p.Available = rdr.GetDateTime(3);
                }
            }
            catch
            {

            }

            //return publication;
        }

        public static int[] FetchPublicationCounts(DateTime from, DateTime to) 
        {
            return publicationCounts;
        }
    }
}