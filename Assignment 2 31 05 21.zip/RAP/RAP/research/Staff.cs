﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;

namespace RAP.Research
{
    public class Staff : Researcher
    {
        public string[] Supervisions { get; set; }
        //number of publications in the past 3 years / 3
        public float ThreeYearAverage 
        {
            get; set;
         
        }

        public int SupervisionsCount
        {
            get; set;

        }

        //performance: 'their three-year average for publications divided by the expected number of publications given their employment level, expressed as a percentage with one decimal place shown'
        public float Performance
        {
            get; set;
        }

    }
}
