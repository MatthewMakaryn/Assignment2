﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;
using RAP;

namespace RAP.Control
{
    public class ResearcherController
    {
        //load the list of researchers with basic details
        public static List<Researcher> LoadResearchers()
        {
            List<Researcher> Researchers = ERDAdapter.FetchBasicResearcherDetails();
            return Researchers;
        }

        //load the full details of a specific researcher
        public static Researcher LoadResearcherDetails(Researcher r)
        {
            Researcher researcher = ERDAdapter.CompleteResearcherDetails(r);
            researcher.Publications = ERDAdapter.FetchBasicPublicationDetails(r);
            return researcher;
        }

    public static List<Researcher> FilterByEmploymentLevel(EmploymentLevel level) 
        {
            //create a new list of researchers
            List<Researcher> researchers = ERDAdapter.FetchBasicResearcherDetails();
            //get researchers matching the specified employment level
            if (level != EmploymentLevel.All) {
                var matching = (from r in researchers
                                where r.CurrentJobLevel == level
                                select r).ToList();
                return matching;
            }
            return researchers;
            
        }

        public static List<Researcher> FilterByName(string name) 
        {
            name = name.ToLower();
            //create a new list of researchers
            List<Researcher> researchers = ERDAdapter.FetchBasicResearcherDetails();
            var matching = (from r in researchers
                           where r.FamilyName.ToLower().Contains(name.ToLower()) || r.GivenName.ToLower().Contains(name.ToLower())
                           select r).ToList();
            return matching;
        }

    }
}
