﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;

namespace RAP.Control
{
    class PublicationController
    {

        public static List<Publication> loadPublicationsFor(Researcher r) 
        {
            List<Publication> publications = ERDAdapter.FetchBasicPublicationDetails(r);
            return publications;
        }

        public static List<Publication> sortPublications(List<Publication> publications, char order)
        {
            if (order == 'a')
            {
                publications = publications.OrderBy(x => x.Year).ToList();
            } else if (order == 'd')
            {
                publications = publications.OrderByDescending(x => x.Year).ToList();
            }
            return publications;
        }
    }
}
