﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;

using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace RAP.Database
{
    public class ERDAdapter
    {
        private static bool reportingErrors = false;

        private const string db = "kit206";
        private const string user = "kit206";
        private const string pass = "kit206";
        private const string server = "alacritas.cis.utas.edu.au";

        private static MySqlConnection conn = null;

        /// Creates and returns (but does not open) the connection to the database.
        private static MySqlConnection GetConnection()
        {
            if (conn == null)
            {
                //Note: This approach is not thread-safe
                string connectionString = String.Format("Database={0};Data Source={1};User Id={2};Password={3}", db, server, user, pass);
                conn = new MySqlConnection(connectionString);
            }
            return conn;
        }

        //retrieve list of basic researcher information from database
        public static List<Researcher> FetchBasicResearcherDetails() 
        {
            List<Researcher> researchers = new List<Researcher>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select id, type, given_name, family_name, title, level from researcher order by given_name", conn);
                rdr = cmd.ExecuteReader();
           
                while (rdr.Read()) 
                {
                    if (rdr.GetString("type") == "Student")
                    {
                        researchers.Add(new Student
                        {
                            ID = rdr.GetInt32("id"),
                            GivenName = rdr.GetString("given_name"),
                            FamilyName = rdr.GetString("family_name"),
                            Title = rdr.GetString("title"),
                            CurrentJobLevel = EmploymentLevel.Student
                        }) ;
                    } 
                    else if (rdr.GetString("type") == "Staff")
                    {
                        researchers.Add(new Staff
                        {
                            ID = rdr.GetInt32("id"),
                            GivenName = rdr.GetString("given_name"),
                            FamilyName = rdr.GetString("family_name"),
                            Title = rdr.GetString("title"),
                            CurrentJobLevel = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString("level"))
                        });
                    }
                }
                rdr.Close();
                
            }
            catch
            {

            }
            conn.Close();
            Console.WriteLine(researchers.Count());
            return researchers;
        }

        //retrieve all of a specific researcher's details from the database
        public static Researcher CompleteResearcherDetails(Researcher r)
        {
            //Researcher researcher = new Researcher();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select unit, campus, email, photo, degree, supervisor_id, level from researcher where id=?id", conn);
                cmd.Parameters.AddWithValue("id", r.ID);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    if (r is Student)
                    {
                        Student researcher = new Student
                        {
                            ID = r.ID,
                            GivenName = r.GivenName,
                            FamilyName = r.FamilyName,
                            Title = r.Title,
                            CurrentJobLevel = r.CurrentJobLevel,
                            School = rdr.GetString("unit"),
                            Campus = rdr.GetString("campus"),
                            Email = rdr.GetString("email"),
                            Photo = rdr.GetString("photo"),
                            Degree = rdr.GetString("degree"),
                            SupervisorID = rdr.GetInt32("supervisor_id"),
                            EarliestStart = rdr.GetDateTime("utas_start"),
                            CurrentJobStart = rdr.GetDateTime("current_start")
                        };

                        rdr.Close();

                        return researcher;
                    }
                    else if (r is Staff)
                    {
                        List<Position> positions = new List<Position>();
                        List<string> supervisions = new List<string>();
                        Staff researcher = new Staff
                        {
                            ID = r.ID,
                            GivenName = r.GivenName,
                            FamilyName = r.FamilyName,
                            Title = r.Title,
                            CurrentJobLevel = r.CurrentJobLevel,
                            School = rdr.GetString("unit"),
                            Campus = rdr.GetString("campus"),
                            Email = rdr.GetString("email"),
                            Photo = rdr.GetString("photo"),
                            EarliestStart = rdr.GetDateTime("utas_start"),
                            CurrentJobStart = rdr.GetDateTime("current_start")
                        };
                        rdr.Close();

                        //retrieve all of their past positions from the database
                        
                        MySqlCommand cmd2 = new MySqlCommand("select level, start, end from position where id=?id and end is not null order by end desc", conn);
                        cmd2.Parameters.AddWithValue("id", r.ID);
                        rdr = cmd2.ExecuteReader();

                        while (rdr.Read())
                        {
                           
                                positions.Add(new Position
                                {
                                    Level = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString("level")),
                                    Start = rdr.GetDateTime("start"),
                                    End = rdr.GetDateTime("end")
                                });
                          
                        }
                        rdr.Close();
                        
                        researcher.Positions = positions;

                        //retrieve all of their supervisions from the database
                        MySqlCommand cmd3 = new MySqlCommand("select given_name, family_name, title from researcher where supervisor_id=?id", conn);
                        cmd3.Parameters.AddWithValue("id", r.ID);
                        rdr = cmd3.ExecuteReader();
                        while (rdr.Read())
                        {
                                supervisions.Add(rdr.GetString("given_name"));

                        }
                        rdr.Close();
                        
                        researcher.Supervisions = supervisions.ToArray();
                       // Console.WriteLine($"supervisions = {researcher.Supervisions.Count()}");
                       // Console.WriteLine(string.Join(", ", researcher.Supervisions));
                        return researcher;
                    }
                }

            } 
            catch
            {
      
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return new  Researcher();
        }

        public static List<Publication> FetchBasicPublicationDetails(Researcher r)
        {
            List<Publication> publications = new List<Publication>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            conn.Open();

            MySqlCommand cmd2 = new MySqlCommand($"select publication.doi, publication.year, publication.title from publication inner join researcher_publication on publication.doi = researcher_publication.doi where researcher_publication.researcher_id = ?id order by year desc, title", conn);
            cmd2.Parameters.AddWithValue("id", r.ID);
            rdr = cmd2.ExecuteReader();
            while (rdr.Read())
            {
                publications.Add(new Publication
                {    
                    DOI = rdr.GetString("doi"),
                    Year = rdr.GetInt32("year"),
                    Title = rdr.GetString("title")
                }) ;
            }
            rdr.Close();
            
            return publications;
        }

        public static Publication CompletePublicationDetails(Publication p)
        {
            Publication publication = new Publication();
            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("authors, type, cite_as, available from publication where doi = ?doi", conn);
                cmd.Parameters.AddWithValue("doi", p.DOI);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    publication.DOI = p.DOI;
                    publication.Year = p.Year;
                    publication.Title = p.Title;
                    publication.Authors = rdr.GetString("authors");
                    publication.Type = EnumToString.ParseEnum<OutputType>(rdr.GetString("type"));
                    publication.CiteAs = rdr.GetString("cite_as");
                    publication.Available = rdr.GetDateTime("available");
                }
            }
            catch (MySqlException e)
            {
                ReportError("loading publications", e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
            
            return publication;
        }


        private static void ReportError(string msg, Exception e)
        {
            if (reportingErrors)
            {
                MessageBox.Show("An error occurred while " + msg + ". Try again later.\n\nError Details:\n" + e,
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}