﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;

namespace RAP.View
{
    /// <summary>
    /// Interaction logic for ResearcherListView.xaml
    /// </summary>
    public partial class ResearcherListView : UserControl
    {
        
        public PublicationListView publicationListView = new PublicationListView();

       
        public ResearcherListView()
        {
            InitializeComponent();
        }

        private void ResearcherList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            //lol rip
            ResearcherDetailsView researcherDetailsView = new ResearcherDetailsView();
        //Researcher selectedResearcher = (Researcher)e.AddedItems[0];
            //selectedResearcher = ResearcherController.LoadResearcherDetails(selectedResearcher);
           // researcherDetailsView.CurrentResearcher = selectedResearcher;
           // Console.WriteLine(researcherDetailsView.CurrentResearcher.Title);
           // researcherDetailsPanel.DataContext = researcherDetailsView.CurrentResearcher;
            

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EmploymentLevel selectedLevel = (EmploymentLevel)employmentLevelDropdown.SelectedItem;
            
            ResearcherList.ItemsSource = ResearcherController.FilterByEmploymentLevel(selectedLevel);
            
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string name = filterByNameField.Text;

            ResearcherList.ItemsSource = ResearcherController.FilterByName(name);
        }
    }
}
