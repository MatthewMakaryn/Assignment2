﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RAP.View;
using RAP.Research;
using RAP.Control;
using RAP.Database;



namespace RAP.Research
{

    public enum EmploymentLevel
    {
        All, Student, A, B, C, D, E
    };

    public class Researcher
    {
        public int ID { get; set; }
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public string Title { get; set; }
        public string School { get; set; }
        public string Campus { get; set; }
        public string Email { get; set; }
        public string Photo { get; set; }

        public EmploymentLevel CurrentJobLevel { get; set; }
        public List<Position> Positions { get; set; }
        public List<Publication> Publications { get; set; }

        public DateTime CurrentJobStart { get; set; }

        public DateTime EarliestStart { get; set; }
        //public Position GetCurrentJob
        //{
        //    get; set;

        //}

        public string CurrentJobTitle
        {
        get
            {
                return Position.ToTitle(CurrentJobLevel);
            }
        }

        

        //public Position GetEarliestJob
        //{
        //    get; set;
 
        //}

   

        public float Tenure
        {
            get; set;

        }

        public int PublicationsCount
        {
            get; set;

        }

        public override String ToString()
        {
            String GivenName = this.GivenName;
            String FamilyName = this.FamilyName;
            String Title = this.Title;
            return $"{GivenName} {FamilyName}, {Title}";
        }

        public String ToStringBasic()
        {
            String GivenName = this.GivenName;
            String FamilyName = this.FamilyName;
            String Title = this.Title;

            return $"{GivenName} {FamilyName}, {Title}";
        }
    }


}