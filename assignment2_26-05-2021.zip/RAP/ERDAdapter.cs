﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace RAP
{
    public class ERDAdapter
    {
        private static bool reportingErrors = false;

        private const string db = "kit206";
        private const string user = "kit206";
        private const string pass = "kit206";
        private const string server = "alacritas.cis.utas.edu.au";

        private static MySqlConnection conn = null;

        /// Creates and returns (but does not open) the connection to the database.
        private static MySqlConnection GetConnection()
        {
            if (conn == null)
            {
                //Note: This approach is not thread-safe
                string connectionString = String.Format("Database={0};Data Source={1};User Id={2};Password={3}", db, server, user, pass);
                conn = new MySqlConnection(connectionString);
            }
            return conn;
        }

        //retrieve list of basic researcher information from database
        public static List<Researcher> FetchBasicResearcherDetails() 
        {
            List<Researcher> researchers = new List<Researcher>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select id, type, given_name, family_name, title, level from researcher order by given_name", conn);
                rdr = cmd.ExecuteReader();
           
                while (rdr.Read()) 
                {
                    Console.WriteLine(rdr.GetString("type"));
                    if (rdr.GetString("type") == "Student")
                    {
                        researchers.Add(new Student
                        {
                            ID = rdr.GetInt32("id"),
                            GivenName = rdr.GetString("given_name"),
                            FamilyName = rdr.GetString("family_name"),
                            Title = rdr.GetString("title"),
                            CurrentJobLevel = EmploymentLevel.Student
                        }) ;
                    } 
                    else if (rdr.GetString("type") == "Staff")
                    {
                        researchers.Add(new Staff
                        {
                            ID = rdr.GetInt32("id"),
                            GivenName = rdr.GetString("given_name"),
                            FamilyName = rdr.GetString("family_name"),
                            Title = rdr.GetString("title"),
                            CurrentJobLevel = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString("level"))
                        });
                    }
                }
            }
            catch
            {

            }
            return researchers;
        }

        //retrieve all of a specific researcher's details from the database
        public static void CompleteResearcherDetails(Researcher r)
        {
            //List<Publication> publications = new List<Publication>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select unit, campus, email, photo, degree, supervisor_id, level from researcher where id=?id", conn);
                cmd.Parameters.AddWithValue("id", r.ID);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    r.School = rdr.GetString("unit");
                    r.Campus = rdr.GetString("campus");
                    r.Email = rdr.GetString("email");
                    r.Photo = rdr.GetString("photo");

                    //if they are a student, add student only data
                    if (r is Student)
                    {
                        (r as Student).Degree = rdr.GetString("degree");
                        (r as Student).SupervisorID = rdr.GetInt32("supervisor_id");
                    }
                    else if (r is Staff)
                    //if they are staff, add list of positions
                    {
                        //retrieve all of their past positions from the database
                        List<Position> positions = new List<Position>();
                        MySqlCommand cmd3 = new MySqlCommand("select level, start, end from position where id=?id order by end desc", conn);
                        cmd3.Parameters.AddWithValue("id", r.ID);
                        rdr = cmd3.ExecuteReader();

                        while (rdr.Read())
                        {
                            positions.Add(new Position
                            {
                                Level = EnumToString.ParseEnum<EmploymentLevel>(rdr.GetString("level")),
                                Start = rdr.GetDateTime("start"),
                                End = rdr.GetDateTime("end")
                            });
                        }
                        (r as Staff).Positions = positions;

                        
                    }

                }

            } 
            catch
            {

            }

            //return researcher;
        }

        public static List<Publication> FetchBasicPublicationDetails(Researcher r)
        {
            List<Publication> publications = new List<Publication>();

            int researcherID = r.ID;
            List<string> publicationDOIs = new List<string>();

            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand($"select researcher_publication.doi from researcher_publication where researcher_publication.researcher_id = {researcherID}", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    publicationDOIs.Add(rdr.GetString(0));
                }
            }
            catch (MySqlException e)
            {
                ReportError("loading researcher_publications", e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }


            //this is incredibly accursed
            string PublicationDOIsAsSQLString = "(";

            foreach (String doi in publicationDOIs){
                PublicationDOIsAsSQLString = PublicationDOIsAsSQLString + "'" + doi + "',";
            }

            PublicationDOIsAsSQLString = PublicationDOIsAsSQLString.Remove(PublicationDOIsAsSQLString.Length - 1, 1) + ")";

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand($"select publication.doi, publication.year, publication.title, from publication where publication.doi in {PublicationDOIsAsSQLString}", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    publications.Add(new Publication
                    {
                        DOI = rdr.GetString(0),
                        Year = rdr.GetInt32(1),
                        Title = rdr.GetString(2)
                    }) ;
                }
            }
            catch (MySqlException e)
            {
                ReportError("loading publications", e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return publications;
        }

        public static void CompletePublicationDetails(Publication p)
        {
            MySqlConnection conn = GetConnection();
            MySqlDataReader rdr = null;

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("authors, type, cite_as, available from publication where doi = ?doi", conn);
                cmd.Parameters.AddWithValue("doi", p.DOI);
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    p.Authors = rdr.GetString(0);
                    p.Type = EnumToString.ParseEnum<OutputType>(rdr.GetString(1));
                    p.CiteAs = rdr.GetString(2);
                    p.Available = rdr.GetDateTime(3);
                }
            }
            catch (MySqlException e)
            {
                ReportError("loading publications", e);
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
            //return publication;
        }

        public static int FetchPublicationCounts(DateTime from, DateTime to) 
        {
            return 0;
        }

        private static void ReportError(string msg, Exception e)
        {
            if (reportingErrors)
            {
                MessageBox.Show("An error occurred while " + msg + ". Try again later.\n\nError Details:\n" + e,
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}