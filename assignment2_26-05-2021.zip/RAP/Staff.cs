﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP
{
    public class Staff : Researcher
    {
        //number of publications in the past 3 years / 3
        public float ThreeYearAverage() 
        {
            List<Publication> Last3Years;

            Last3Years = (from paper in this.Publications
                          where DateTime.Compare(paper.Available, DateTime.Now.AddYears(-3)) > 1 && DateTime.Compare(paper.Available, DateTime.Now) < 1
                          select paper).ToList();

            return ((float)Last3Years.Count / (float)3);
        }

        //performance: 'their three-year average for publications divided by the expected number of publications given their employment level, expressed as a percentage with one decimal place shown'
        public float Performance()
        {
            float expectedAverage = (float)0.5;
            float performance;

            switch (this.CurrentJobLevel){
                case EmploymentLevel.A: expectedAverage = (float)0.5;
                                        break;

                case EmploymentLevel.B: expectedAverage = (float)1;
                                        break;

                case EmploymentLevel.C: expectedAverage = (float)2;
                                        break;

                case EmploymentLevel.D: expectedAverage = (float)3.2;
                                        break;

                case EmploymentLevel.E: expectedAverage = (float)4;
                                        break;
            }

            performance = this.ThreeYearAverage() / expectedAverage;

            return performance;
        }

      
    }
}
