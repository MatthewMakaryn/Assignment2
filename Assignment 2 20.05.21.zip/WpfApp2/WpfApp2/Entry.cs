﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;


namespace aaaa
{
    class Entry
    {

        static void printBasicDetails(List<Researcher> Researchers)
        {
            for (int i = 0; i < Researchers.Count; i++)
            {
                String toPrint = Researchers[i].ToStringBasic();

                Console.WriteLine($"{toPrint}\n");
            }
        }

        static void printFullDetails(List<Researcher> Researchers)
        {
            for (int i = 0; i < Researchers.Count; i++)
            {
                String toPrint = Researchers[i].ToString();

                Console.WriteLine($"{toPrint}\n");
            }
        }

        static void printFullDetailsByGivenName(List<Researcher> Researchers)
        {
            Console.WriteLine("Please enter part of a given name");
            String targetName = Console.ReadLine();

            List<Researcher> sorted = new List<Researcher>();

            for (int i = 0; i < Researchers.Count; i++)
            {
                if (Researchers[i].GivenName.Contains(targetName))
                {
                    sorted.Add(Researchers[i]);
                }
            }

            for (int i = 0; i < sorted.Count; i++)
            {
                String toPrint = sorted[i].ToString();
                Console.WriteLine($"{toPrint}\n");
            }
        }

        static void printFullDetailsByFamilyName(List<Researcher> Researchers)
        {
            Console.WriteLine("Please enter part of a family name");
            String targetName = Console.ReadLine();

            List<Researcher> sorted = new List<Researcher>();

            for (int i = 0; i < Researchers.Count; i++)
            {
                if (Researchers[i].FamilyName.Contains(targetName))
                {
                    sorted.Add(Researchers[i]);
                }
            }

            for (int i = 0; i < sorted.Count; i++)
            {
                String toPrint = sorted[i].ToString();
                Console.WriteLine($"{toPrint}\n");
            }
        }

        static void Main(String[] args)
        {
            List<Researcher> Researchers = Staff.LoadAll();

            int command = 1;

            while (command != 0)
            {
                Console.WriteLine("Please select a command: \n" +
                                  "0. Quit \n" +
                                  "1. Display basic details for all researchers \n" +
                                  "2. Display full details for all researchers \n" +
                                  "3. Display full details for (a) specific researcher(s) (search by given name) \n" +
                                  "4. Display full details for (a) specific researcher(s) (search by family name) \n");

                command = Convert.ToInt32(Console.ReadLine());

                switch (command)
                {

                    case 0:
                        Console.WriteLine("Goodbye \n");
                        break;

                    case 1:
                        printBasicDetails(Researchers);
                        break;

                    case 2:
                        printFullDetails(Researchers);
                        break;

                    case 3:
                        printFullDetailsByGivenName(Researchers);
                        break;

                    case 4:
                        printFullDetailsByFamilyName(Researchers);
                        break;

                    default:
                        Console.WriteLine("Invalid Input \n");
                        break;

                }

                Console.WriteLine("");
            }
        }
    }
}