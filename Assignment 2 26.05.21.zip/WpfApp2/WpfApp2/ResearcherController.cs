﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP
{
    public class ResearcherController
    {
        public static List<Researcher> Researchers { get; set; }
        public static Researcher Researcher { get; set; }

        //load the list of researchers with basic details
        public static List<Researcher> LoadResearchers()
        {
            Researchers = ERDAdapter.FetchBasicResearcherDetails();
            return Researchers;
        }

        //load the full details of a specific researcher
        public static Researcher LoadResearcherDetails() 
        {
            Researcher = ERDAdapter.CompleteResearcherDetails();
            return Researcher;
        }

        public static void FilterByEmploymentLevel(EmploymentLevel level) 
        {
            
            //return researchers;
        }

        public static void FilterByName(string name) {

            return researchers;
        }

    }
}
