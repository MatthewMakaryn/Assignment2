﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace RAP
{

    public enum EmploymentLevel
    {
        Student, A, B, C, D, E
    };

    public class Researcher
    {
        public int ID { get; set; }
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public string Title { get; set; }
        public string School { get; set; }
        public string Campus { get; set; }
        public string Email { get; set; }
        public string Photo { get; set; }

        public EmploymentLevel CurrentJobLevel { get; set; }
        public List<Position> Positions { get; set; }
        public List<Publication> Publications { get; set; }




        public Position GetCurrentJob
        {
            get
            {
                var toBeReturned = from job in Positions
                                   where job.End == null
                                   select job;

                return (Position)toBeReturned;
            }
        }

        public string CurrentJobTitle
        {
        get
            {
                return Position.ToTitle(CurrentJobLevel);
            }
        }

        public DateTime CurrentJobStart
        {
            get
            {
                return this.GetCurrentJob.Start;
            }
        }

        public Position GetEarliestJob
        {
            get
            {
                Position currentEarliest = this.Positions[0];

                var toBeReturned = from job in Positions
                                   where (DateTime.Compare(job.Start, currentEarliest.Start) < 1)
                                   select job;

                return (Position)toBeReturned;
            }
        }

        public DateTime EarliestStart
        {
            get
            {
                return this.GetEarliestJob.Start;
            }
        }

        public float Tenure
        {
            get
            {
                return ((float)DateTime.Now.Subtract(this.EarliestStart).Days) / (float)365.0;
            }
        }

        public int PublicationsCount
        {
            get
            {
                return this.Publications.Count;
            }
        }

        public override String ToString()
        {
            int ID = this.ID;
            String GivenName = this.GivenName;
            String FamilyName = this.FamilyName;
            String Title = this.Title;
            String School = this.School;
            String Campus = this.Campus;
            String Email = this.Email;
            String Photo = this.Photo;

            return $"{ID} \n{GivenName} {FamilyName}, {Title} {School} \n{Campus} \n{Email} \n{Photo}";
        }

        public String ToStringBasic()
        {
            String GivenName = this.GivenName;
            String FamilyName = this.FamilyName;
            String Title = this.Title;

            return $"{ID} \n{GivenName} {FamilyName}, {Title}";
        }
    }


}