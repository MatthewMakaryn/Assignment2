﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RAP
{
    public class Position
    {
        public EmploymentLevel Level { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }


        public string Title()
        {
            return ToTitle(this.Level);
        }

        public static string ToTitle(EmploymentLevel L)
        {
            string toBeReturned = "";

            switch (L)
            {

                case EmploymentLevel.Student:
                    toBeReturned = "Student";
                    break;

                case EmploymentLevel.A:
                    toBeReturned = "Postdoc";
                    break;

                case EmploymentLevel.B:
                    toBeReturned = "Lecturer";
                    break;

                case EmploymentLevel.C:
                    toBeReturned = "Senior Lecturer";
                    break;

                case EmploymentLevel.D:
                    toBeReturned = "Associate Professor";
                    break;

                case EmploymentLevel.E:
                    toBeReturned = "Professor";
                    break;
            }
            return toBeReturned;
        }
    }

}
