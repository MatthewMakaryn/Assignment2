﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP
{
    public class Staff : Researcher
    {
        //number of publications in the past 3 years / 3
        public float ThreeYearAverage() 
        {
            return average;
        }

        //performance: 'their three-year average for publications divided by the expected number of publications given their employment level, expressed as a percentage with one decimal place shown'
        public float Performance()
        {
            return performance;
        }

        public override string ToString()
        {
            int ID = this.ID;
            string GivenName = this.GivenName;
            string FamilyName = this.FamilyName;
            string Title = this.Title;
            string School = this.School;
            string Campus = this.Campus;
            string Email = this.Email;
            string Photo = this.Photo;
        

            return $"{ID} \n{GivenName} {FamilyName}, {Title} {School} \n{Campus} \n{Email} \n{Photo}";
        }
    }
}
