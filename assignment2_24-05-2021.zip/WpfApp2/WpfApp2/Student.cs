﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAP
{
    public class Student : Researcher
    {
        public string Degree { get; set; }
        public int SupervisorID { get; set; }

        public override string ToString()
        {
            int ID = this.ID;
            string GivenName = this.GivenName;
            string FamilyName = this.FamilyName;
            string Title = this.Title;
            string School = this.School;
            string Campus = this.Campus;
            string Email = this.Email;
            string Photo = this.Photo;
            string Degree = this.Degree;

            return $"{ID} \n{GivenName} {FamilyName}, {Title} {School} \n{Campus} \n{Email} \n{Photo} \n{Degree}";
        }

    }
  
}
